import { expect, test } from '@playwright/test';
import { MESSAGES } from '../../src/i18n/messages';

for (const viewport of [{ width: 390, height: 568 }, { width: 390, height: 844 }, { width: 1280, height: 720 }]) {
  test.describe(`${viewport.width}x${viewport.height}`, () => {
    test.use({ viewport });
    test.beforeEach(async ({ page }, info) => {
      await page.addInitScript(lang => localStorage.setItem('ghost-rehearsal.lang', lang), info.project.name.endsWith('zh') ? 'zh' : 'en');
      await page.goto('./');
    });

    test('invalid import stacks visually and Escape closes one layer', async ({ page }, info) => {
      const t = MESSAGES[info.project.name.endsWith('zh') ? 'zh' : 'en'];
      const picker = page.waitForEvent('filechooser');
      await page.getByRole('button', { name: t.eventSetup.import, exact: true }).click();
      await (await picker).setFiles({ name: 'invalid.json', mimeType: 'application/json', buffer: Buffer.from('{}') });
      const error = page.getByRole('dialog', { name: t.stage.checksTitle });
      await expect(error).toBeVisible();
      await expect.soft(error.evaluate(element => {
        const rect = element.getBoundingClientRect();
        return element.contains(document.elementFromPoint(rect.x + rect.width / 2, rect.y + rect.height / 2));
      })).resolves.toBe(true);
      await page.screenshot({ path: info.outputPath('import-stack.png') });
      await page.keyboard.press('Escape');
      await expect.soft(page.getByRole('dialog', { name: t.eventSetup.title })).toBeVisible({ timeout: 1500 });
      await expect.soft(page.getByRole('button', { name: t.eventSetup.import, exact: true })).toBeFocused({ timeout: 1500 });
      await page.keyboard.press('Escape');
      await expect(page.getByRole('dialog')).toHaveCount(0);
    });

    test('new event accepts an empty numeric draft and keeps footer reachable', async ({ page }, info) => {
      const t = MESSAGES[info.project.name.endsWith('zh') ? 'zh' : 'en'];
      await page.getByRole('textbox', { name: t.dialogs.eventName }).fill('Forms rehearsal');
      const number = page.getByLabel(t.dialogs.count, { exact: true });
      await number.selectText();
      await number.press('Backspace');
      await expect.soft(number).toHaveValue('', { timeout: 1500 });
      const create = page.getByRole('button', { name: t.eventSetup.create, exact: true });
      await create.focus();
      const box = await create.boundingBox();
      expect.soft(box && box.y >= 0 && box.y + box.height <= viewport.height).toBe(true);
      await expect.soft(create).toBeInViewport({ ratio: 1, timeout: 1500 });
      await page.screenshot({ path: info.outputPath('event-footer.png') });
    });

    test('resource tabs support arrow keys and panel relationships', async ({ page }, info) => {
      const t = MESSAGES[info.project.name.endsWith('zh') ? 'zh' : 'en'];
      await page.getByRole('button', { name: t.eventSetup.demo, exact: true }).click();
      await page.getByRole('tab', { name: t.modes.Build, exact: true }).click();
      await page.locator('.side-link').filter({ hasText: t.sidebar.resources }).click();
      const first = page.getByRole('tab', { name: t.dialogs.tabResources, exact: true });
      const second = page.getByRole('tab', { name: t.dialogs.tabAssignments, exact: true });
      await first.focus();
      await first.press('ArrowRight');
      await expect.soft(second).toBeFocused({ timeout: 1500 });
      await expect.soft(second).toHaveAttribute('aria-selected', 'true', { timeout: 1500 });
      await expect.soft(page.getByRole('tabpanel', { name: t.dialogs.tabAssignments, exact: true })).toBeVisible({ timeout: 1500 });
    });
  });
}
